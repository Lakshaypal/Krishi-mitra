import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Layout } from './components/layout/Layout';
import { HomePage } from './pages/HomePage';
import { DiagnosisPage } from './pages/DiagnosisPage';
import { SourcingPage } from './pages/SourcingPage';
import { MarketPage } from './pages/MarketPage';
import { StrategyPage } from './pages/StrategyPage';
import { SchemesPage } from './pages/SchemesPage';

export default function App() {
  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/diagnosis" element={<DiagnosisPage />} />
          <Route path="/sourcing" element={<SourcingPage />} />
          <Route path="/market" element={<MarketPage />} />
          <Route path="/strategy" element={<StrategyPage />} />
          <Route path="/schemes" element={<SchemesPage />} />
        </Routes>
      </Layout>
    </Router>
  );
}
